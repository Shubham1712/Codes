package com.lambda_s3.AWSLambdaS3;

import java.net.URLDecoder;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.amazonaws.services.lambda.runtime.events.S3Event;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.event.S3EventNotification;

public class HelloWorld implements RequestHandler<S3Event, String> {

	public String handleRequest(S3Event input, Context context) {

		
		try {
			S3EventNotification.S3EventNotificationRecord record = input.getRecords().get(0);
			System.out.println("Bucket Name is - "+record.getS3().getBucket().getName());
			System.out.println("File path is - "+record.getS3().getObject().getKey());

            String bkt = record.getS3().getBucket().getName();
            String key = record.getS3().getObject().getKey().replace('+', ' ');
            key = URLDecoder.decode(key, "UTF-8");

            // Read the source file as text
            AmazonS3 s3Client = new AmazonS3Client();
            String body = s3Client.getObjectAsString(bkt, key);
            System.out.println("Body: " + body);
            return "ok";
        } catch (Exception e) {
            System.err.println("Exception: " + e);
            return "error";
        }
	}

}
