package com.amazonaws;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.amazonaws.services.lambda.runtime.events.SQSEvent;
import com.amazonaws.services.lambda.runtime.events.SQSEvent.SQSMessage;

public class LambdaFunctionHandler implements RequestHandler<SQSEvent, Void> {

	@Override
	public Void handleRequest(SQSEvent input, Context context) {

		/*
		 * String url =
		 * "https://sqs.us-east-1.amazonaws.com/834697846023/sample-lambda-queue";
		 * ReceiveMessageRequest receiveMessageRequest = new ReceiveMessageRequest(url)
		 * .withWaitTimeSeconds(10) .withMaxNumberOfMessages(10);
		 */

		// List<Message> sqsMessages =
		// input.receiveMessage(receiveMessageRequest).getMessages();

		for (SQSMessage msg : input.getRecords()) {
			System.out.println(new String(msg.getBody().replace("\\", "")));

		}

		// AWSCredentials credentials = null;
		/*
		 * String key = "MyObjectKey"; String bucketName = "mylambda-demo";
		 * 
		 * String sqsMessage = input.getRecords().get(0).getBody();
		 * System.out.println("sqsMessage - "+sqsMessage);
		 * 
		 * //credentials = new ProfileCredentialsProvider("default").getCredentials();
		 * 
		 * AmazonS3 s3 = AmazonS3ClientBuilder.standard().withCredentials(new
		 * AWSStaticCredentialsProvider(credentials)).withRegion(Regions.US_EAST_1).
		 * build();
		 * 
		 * AmazonS3 s3 = AmazonS3ClientBuilder.standard().withRegion(Regions.US_EAST_1)
		 * .withCredentials(new AWSStaticCredentialsProvider(new BasicAWSCredentials("",
		 * ""))) .build();
		 * 
		 * s3.putObject(bucketName, key, sqsMessage);
		 */

		System.out.println("-----------------***----------------");

		return null;
	}

}
